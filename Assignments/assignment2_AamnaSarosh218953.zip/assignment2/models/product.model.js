const mongoose = require('mongoose');
 
//Attributes of the Product object
var productSchema = new mongoose.Schema({
productId: {
type: String,
required: 'This field is required!'
},
productName: {
type: String
},
productDesc: {
type: String
},
productPrice: {
type: String
}
});
 
mongoose.model('Product', productSchema);